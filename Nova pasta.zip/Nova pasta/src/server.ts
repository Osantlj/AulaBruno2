import fastify from "fastify"
import type { FastifyInstance } from "fastify"

// informarções de log do sistema 
const app: FastifyInstance = fastify({ logger: false });

app.listen(
    {
    port: 3100,
    },
    () => console.log('Server Runing...'),
)