export interface Contacts {
    id: string;
    nome: string;
    email: string;
    phone: string;
    userId: string;
}