import type UserRepository { UserRepository } from "../interfaces/user.interface";


class UserRepositoryImpl implements UserRepository {
    async create(data: UserCreate): Promise<User> {
}    